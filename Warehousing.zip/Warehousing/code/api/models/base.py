from datetime import datetime

class Base:
    def __init__():
        pass

    def get_timestamp(self):
        return datetime.utcnow().isoformat() + "Z"